## Задача 2. Дзен Пайтона
У вас есть файл zen.txt, в котором хранится так называемый “Дзен Пайтона” - текст философии программирования на языке Python.

Напишите программу, которая выводит на экран все строки данного файла в обратном порядке.

Кстати, попробуйте открыть консоль Питона и ввести команду “import this”.

#### Результат работы программы:
````
Namespaces are one honking great idea -- let's do more of those!
If the implementation is easy to explain, it may be a good idea.
If the implementation is hard to explain, it's a bad idea.
Although never is often better than *right* now.
......
......
````
