# TODO здесь писать код
names = ["Артемий", "Борис", "Влад", "Гоша", "Дима", "Евгений", "Женя", "Захар"]
for i in range(len(names)):
    if i % 2 == 0:
        print(names[i])
