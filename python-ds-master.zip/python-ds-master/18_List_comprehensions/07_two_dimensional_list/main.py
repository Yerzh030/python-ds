# TODO здесь писать код
x = 1
arr =[[j+i*4 for i in range(3)] for j in range(1,5)]
print(arr)
